// Singleton.Java
// Demonstra o padrão de projeto Singleton

// SingletonTest.java
// Tenta criar dois objetos Singleton

public class SingletonTest{
    // executa SingletonExample
    public static void main( String args[] ) {
        Singleton firstSingleton;
        Singleton secondSingleton;
		Singleton C;
		Singleton D;

        // cria objetos Singleton
        firstSingleton = Singleton.getInstance();
        secondSingleton = Singleton.getInstance();
		C = Singleton.getInstance();
		D = Singleton.getInstance();
		

        // o dois “Singletons” devem se referir ao mesmo Singleton
        if ( firstSingleton == D )
            System.err.println( "firstSingleton and secondSingleton D " + "refer to the same Singleton object" );
    } // fim de main
} // fim da classe SingletonTest


